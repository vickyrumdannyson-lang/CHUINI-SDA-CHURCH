
import React, {useState} from 'react';
import {SafeAreaView, View, Text, ScrollView, TouchableOpacity, StyleSheet, StatusBar} from 'react-native';
import {NavigationContainer} from '@react-navigation/native';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import {Ionicons} from '@expo/vector-icons';
import {Image} from 'react-native';

const navy='#102A43', gold='#D6A84F', ink='#182B3A', muted='#6B7C8F', pale='#F3F6F9';
const sections=[
 ['Biblia','book','Soma Neno la Mungu','Biblia ya Kiswahili itaunganishwa katika toleo la maudhui.'],
 ['Kitabu cha Nyimbo','musical-notes','Nyimbo kubwa na ndogo','Hifadhi ya nyimbo na maneno itaongezwa kwa maudhui yaliyoidhinishwa.'],
 ['Somo la Sabato','school','Jifunze kila siku','Masomo ya Sabato, mijadala na nyenzo za kujifunzia.'],
 ['Matangazo','megaphone','Habari za kanisa','Matangazo, ratiba na taarifa rasmi za Chuini SDA Church.'],
 ['Kwaya na Media','videocam','Huduma za uimbaji na media','Picha, video na taarifa za huduma za kanisa.'],
 ['Mijadala','chatbubbles','Ushirika na mawasiliano','Sehemu ya mazungumzo ya washiriki; itahitaji akaunti na backend.'],
 ['Duka la Vitabu','library','Vitabu na machapisho','Orodha ya vitabu na maelekezo ya upatikanaji.'],
 ['Kuhusu Kanisa','information-circle','Karibu Chuini SDA Church','Historia, huduma, mahali na mawasiliano ya kanisa.'],
];
function Header(){return <View style={s.header}>
 <View style={s.logo}><Image source={require("./assets/chuini-sda-logo.png")} style={{width:44,height:44,borderRadius:10}} resizeMode="contain"/></View>
 <View style={{flex:1}}><Text style={s.brand}>CHUINI SDA CHURCH</Text><Text style={s.subbrand}>ZANZIBAR • SEVENTH-DAY ADVENTIST</Text></View>
 <Ionicons name="notifications-outline" size={23} color="white"/>
 </View>}
function Home({navigation}){return <SafeAreaView style={s.safe}><Header/><ScrollView contentContainerStyle={s.content}>
 <View style={s.hero}><Text style={s.kicker}>KARIBU NYUMBANI</Text><Text style={s.heroTitle}>Karibu Chuini SDA Church</Text><Text style={s.heroText}>Mahali pa ibada, kujifunza Neno la Mungu na kukua katika ushirika.</Text>
 <View style={s.verse}><Text style={s.verseText}>“Nami nitakwenda, nikimsubiri Yesu.”</Text></View></View>
 <Text style={s.heading}>Huduma na sehemu muhimu</Text><View style={s.grid}>{sections.map(([name,icon,desc],i)=><TouchableOpacity key={name} style={s.tile} onPress={()=>navigation.navigate(name)}><View style={s.icon}><Ionicons name={icon} size={23} color={navy}/></View><Text style={s.tileTitle}>{name}</Text><Text style={s.tileDesc}>{desc}</Text></TouchableOpacity>)}</View>
 <View style={s.notice}><Ionicons name="calendar-outline" size={22} color={gold}/><View style={{flex:1}}><Text style={s.noticeTitle}>Ratiba na matangazo</Text><Text style={s.noticeText}>Taarifa rasmi zitaonekana hapa baada ya kuunganishwa na mfumo wa usimamizi.</Text></View></View>
 <Text style={s.footer}>“Mambo yote na yatendeke kwa uzuri na kwa utaratibu.” — 1 Wakorintho 14:40</Text>
 </ScrollView></SafeAreaView>}
function Detail({route}){const item=sections.find(x=>x[0]===route.name);return <SafeAreaView style={s.safe}><Header/><ScrollView contentContainerStyle={s.content}><View style={s.detailIcon}><Ionicons name={item?.[1]||'apps'} size={34} color={gold}/></View><Text style={s.heading}>{route.name}</Text><Text style={s.detailText}>{item?.[3]||'Sehemu hii itaonyesha taarifa husika.'}</Text><View style={s.notice}><Ionicons name="construct-outline" size={22} color={gold}/><View style={{flex:1}}><Text style={s.noticeTitle}>Inaandaliwa</Text><Text style={s.noticeText}>Muundo wa app uko tayari; maudhui halisi, akaunti, na usimamizi wa mtandaoni vinahitaji chanzo cha data na usanidi wa backend.</Text></View></View></ScrollView></SafeAreaView>}
function TabHome({navigation}){return <Home navigation={navigation}/>}
const Tab=createBottomTabNavigator();
function App(){return <><StatusBar barStyle="light-content" backgroundColor={navy}/><NavigationContainer><Tab.Navigator screenOptions={({route})=>({headerShown:false,tabBarActiveTintColor:gold,tabBarInactiveTintColor:'#8190A0',tabBarStyle:{height:62,paddingBottom:8,paddingTop:7},tabBarIcon:({color,size})=><Ionicons name={route.name==='Mwanzo'?'home':route.name==='Biblia'?'book':route.name==='Matangazo'?'megaphone':'menu'} size={size} color={color}/>})}>
<Tab.Screen name="Mwanzo" component={TabHome}/>{['Biblia','Matangazo','Zaidi'].map((n)=><Tab.Screen key={n} name={n}>{({navigation})=><Detail route={{name:n==='Zaidi'?'Kuhusu Kanisa':n}}/>}</Tab.Screen>)}
</Tab.Navigator></NavigationContainer></>}
const s=StyleSheet.create({
 safe:{flex:1,backgroundColor:pale},header:{backgroundColor:navy,paddingHorizontal:18,paddingVertical:14,flexDirection:'row',alignItems:'center',gap:12},logo:{width:48,height:48,borderRadius:15,backgroundColor:'#203D55',alignItems:'center',justifyContent:'center',borderWidth:1,borderColor:'#496176'},brand:{color:'white',fontSize:15,fontWeight:'900',letterSpacing:1},subbrand:{color:'#C5D1DC',fontSize:9,letterSpacing:1,marginTop:3},content:{padding:17,paddingBottom:30},hero:{backgroundColor:navy,borderRadius:22,padding:21,marginBottom:22},kicker:{color:gold,fontSize:10,fontWeight:'800',letterSpacing:2},heroTitle:{color:'white',fontSize:26,fontWeight:'900',marginTop:9},heroText:{color:'#D4DEE7',fontSize:14,lineHeight:21,marginTop:8},verse:{borderLeftWidth:3,borderLeftColor:gold,paddingLeft:11,marginTop:17},verseText:{color:'#F5DDAA',fontStyle:'italic',fontSize:13},heading:{fontSize:19,fontWeight:'900',color:ink,marginBottom:13},grid:{flexDirection:'row',flexWrap:'wrap',justifyContent:'space-between'},tile:{width:'48.2%',backgroundColor:'white',borderRadius:17,padding:14,marginBottom:12,minHeight:150,borderWidth:1,borderColor:'#E7ECF1'},icon:{width:42,height:42,borderRadius:13,backgroundColor:'#EAF0F5',alignItems:'center',justifyContent:'center',marginBottom:10},tileTitle:{fontSize:14,fontWeight:'800',color:ink},tileDesc:{fontSize:11,color:muted,lineHeight:16,marginTop:5},notice:{flexDirection:'row',gap:12,alignItems:'flex-start',backgroundColor:'white',borderRadius:16,padding:16,marginTop:8,borderWidth:1,borderColor:'#E7ECF1'},noticeTitle:{fontWeight:'800',fontSize:14,color:ink},noticeText:{fontSize:12,color:muted,lineHeight:18,marginTop:4},footer:{textAlign:'center',fontSize:11,color:muted,lineHeight:18,marginTop:23},detailIcon:{width:68,height:68,borderRadius:20,backgroundColor:navy,alignItems:'center',justifyContent:'center',marginBottom:16},detailText:{fontSize:15,color:muted,lineHeight:23,marginBottom:18}
});
export default App;
