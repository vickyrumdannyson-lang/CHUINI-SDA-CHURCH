# CHUINI SDA CHURCH — Android app

React Native + Expo Android application. This is a native Android project (not a website).

## Build APK locally with Docker

```bash
docker build -f Dockerfile.android -t chuini-sda-android .
docker run --rm -v "$PWD/out:/out" chuini-sda-android
```

APK output: `out/chuini-sda.apk`.

## GitHub CI/CD

1. Since you do not yet have a GitHub account, create one at https://github.com/signup, then create a repository named `chuini-sda-church`.
2. Upload/push this project to the repository's `main` branch.
3. Open **Actions** → **Build Android APK** → **Run workflow**.
4. Download `chuini-sda-android-apk` from the successful workflow run's Artifacts.

A push to `main` also triggers a build.

## Branding image

The supplied official CHUINI SDA CHURCH logo is included as `assets/chuini-sda-logo.png` and is used in the app header and Android launcher icons.

## Important production work still required

This starter provides the native app shell, navigation, visual theme, Docker build recipe and GitHub Actions workflow. A production-ready church platform still needs approved Bible/hymn/lesson content, an API/backend, admin authentication and roles, database/storage, push notifications, and privacy/security configuration. No admin password or private key is embedded in this repository.
